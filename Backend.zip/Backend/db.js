const mongoose = require("mongoose");
const URIstring="mongodb://localhost:27017/Yahya"
const connectMongo=()=>{
    mongoose.connect(
        URIstring, ()=> console.log("Connection Successful")
    )
}
module.exports=connectMongo;