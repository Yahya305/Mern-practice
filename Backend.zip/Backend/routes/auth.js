const express = require("express");
const User = require("../models/User")
const router = express.Router();

router.post("/", async (req,res)=>{
    try {
        const {
            firstName,
            lastName,
            email,
            password
        }= req.body;
        const users = new User({
            firstName,
            lastName,
            email,
            password
        });
        console.log(User)
        await users.save();
        console.log(req.body)
        res.status(200).json(req.body)
        
    } catch (error) {
        console.log(error)
        res.status(404).json({message:error.message})
        
    }
})
module.exports= router